# Mrtool
pkg update

pkg upgrade

pkg install git

pkg install python

pkg install python2

pip2 install requests

pip2 install mechanize

pip2 install lolcat

pip2 install bs4

apt install nodejs-lts

rm -rf Mrtool

git clone https://github.com/mrpardesi007/Mrtool.git

cd Mrtool

python2 Mr2.Max
